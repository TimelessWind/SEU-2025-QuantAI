#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
策略API接口模块
提供策略管理和回测结果查询的REST API
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import logging
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
import uuid

from strategy_engine import StrategyEngine
from backtest_engine import BacktestEngine, BacktestResult
from strategy_editor import StrategyEditor

# 配置日志
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__)
CORS(app)  # 允许跨域请求

# 全局变量
strategy_engine = None
backtest_engine = None
strategy_editor = None


def init_engines(db_password: str = None):
    """初始化策略引擎和回测引擎"""
    global strategy_engine, backtest_engine, strategy_editor
    strategy_engine = StrategyEngine(db_password)
    backtest_engine = BacktestEngine(db_password)
    strategy_editor = StrategyEditor(db_password)
    logger.info("策略引擎、回测引擎和策略编辑器初始化完成")


@app.route('/api/strategies', methods=['GET'])
def get_strategies():
    """获取可用策略列表"""
    try:
        strategies = strategy_engine.get_available_strategies()
        return jsonify({
            'success': True,
            'data': strategies,
            'message': '获取策略列表成功'
        })
    except Exception as e:
        logger.error(f"获取策略列表失败: {e}")
        return jsonify({
            'success': False,
            'message': f'获取策略列表失败: {str(e)}'
        }), 500


@app.route('/api/strategies/<strategy_type>/run', methods=['POST'])
def run_strategy():
    """运行策略生成信号"""
    try:
        data = request.get_json()
        
        # 验证必需参数
        required_fields = ['stock_code', 'start_date', 'end_date', 'strategy_type']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'缺少必需参数: {field}'
                }), 400
        
        # 提取参数
        stock_code = data['stock_code']
        start_date = data['start_date']
        end_date = data['end_date']
        strategy_type = data['strategy_type']
        strategy_params = data.get('strategy_params', {})
        
        # 运行策略
        signals = strategy_engine.run_strategy(
            stock_code=stock_code,
            start_date=start_date,
            end_date=end_date,
            strategy_type=strategy_type,
            **strategy_params
        )
        
        # 转换数据格式
        signals_data = signals.to_dict('records')
        
        # 统计信号
        buy_signals = len(signals[signals['signal'] == 1])
        sell_signals = len(signals[signals['signal'] == -1])
        
        return jsonify({
            'success': True,
            'data': {
                'signals': signals_data,
                'statistics': {
                    'total_signals': len(signals),
                    'buy_signals': buy_signals,
                    'sell_signals': sell_signals
                }
            },
            'message': '策略运行成功'
        })
        
    except Exception as e:
        logger.error(f"运行策略失败: {e}")
        return jsonify({
            'success': False,
            'message': f'运行策略失败: {str(e)}'
        }), 500


@app.route('/api/backtest/run', methods=['POST'])
def run_backtest():
    """运行回测"""
    try:
        data = request.get_json()
        
        # 验证必需参数
        required_fields = ['stock_code', 'start_date', 'end_date', 'strategy_type']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'缺少必需参数: {field}'
                }), 400
        
        # 提取参数
        stock_code = data['stock_code']
        start_date = data['start_date']
        end_date = data['end_date']
        strategy_type = data['strategy_type']
        strategy_params = data.get('strategy_params', {})
        initial_capital = data.get('initial_capital', 100000.0)
        commission_rate = data.get('commission_rate', 0.001)
        user_id = data.get('user_id', 'default_user')
        strategy_id = data.get('strategy_id', f'STRAT_{strategy_type}')
        
        # 运行回测
        result = backtest_engine.run_backtest(
            stock_code=stock_code,
            start_date=start_date,
            end_date=end_date,
            strategy_type=strategy_type,
            initial_capital=initial_capital,
            commission_rate=commission_rate,
            **strategy_params
        )
        
        # 保存回测结果
        report_id = backtest_engine.save_backtest_result(
            result=result,
            strategy_id=strategy_id,
            user_id=user_id,
            stock_code=stock_code,
            start_date=start_date,
            end_date=end_date
        )
        
        return jsonify({
            'success': True,
            'data': {
                'report_id': report_id,
                'performance': {
                    'initial_capital': result.initial_capital,
                    'final_capital': result.final_capital,
                    'total_return': result.total_return,
                    'annual_return': result.annual_return,
                    'max_drawdown': result.max_drawdown,
                    'sharpe_ratio': result.sharpe_ratio,
                    'win_rate': result.win_rate,
                    'profit_loss_ratio': result.profit_loss_ratio,
                    'trade_count': result.trade_count
                },
                'trades': result.trades,
                'equity_curve': result.equity_curve,
                'daily_returns': result.daily_returns
            },
            'message': '回测完成'
        })
        
    except Exception as e:
        logger.error(f"回测失败: {e}")
        return jsonify({
            'success': False,
            'message': f'回测失败: {str(e)}'
        }), 500


@app.route('/api/backtest/compare', methods=['POST'])
def compare_strategies():
    """比较多个策略"""
    try:
        data = request.get_json()
        
        # 验证必需参数
        required_fields = ['stock_code', 'start_date', 'end_date', 'strategies']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'缺少必需参数: {field}'
                }), 400
        
        # 提取参数
        stock_code = data['stock_code']
        start_date = data['start_date']
        end_date = data['end_date']
        strategies = data['strategies']
        initial_capital = data.get('initial_capital', 100000.0)
        
        # 比较策略
        results = backtest_engine.compare_strategies(
            stock_code=stock_code,
            start_date=start_date,
            end_date=end_date,
            strategies=strategies,
            initial_capital=initial_capital
        )
        
        # 格式化结果
        comparison_data = {}
        for strategy_name, result in results.items():
            comparison_data[strategy_name] = {
                'performance': {
                    'initial_capital': result.initial_capital,
                    'final_capital': result.final_capital,
                    'total_return': result.total_return,
                    'annual_return': result.annual_return,
                    'max_drawdown': result.max_drawdown,
                    'sharpe_ratio': result.sharpe_ratio,
                    'win_rate': result.win_rate,
                    'profit_loss_ratio': result.profit_loss_ratio,
                    'trade_count': result.trade_count
                },
                'equity_curve': result.equity_curve
            }
        
        return jsonify({
            'success': True,
            'data': comparison_data,
            'message': '策略比较完成'
        })
        
    except Exception as e:
        logger.error(f"策略比较失败: {e}")
        return jsonify({
            'success': False,
            'message': f'策略比较失败: {str(e)}'
        }), 500


@app.route('/api/backtest/results', methods=['GET'])
def get_backtest_results():
    """获取回测结果列表"""
    try:
        # 获取查询参数
        user_id = request.args.get('user_id')
        strategy_id = request.args.get('strategy_id')
        limit = int(request.args.get('limit', 100))
        
        # 获取回测结果
        results = backtest_engine.get_backtest_results(
            user_id=user_id,
            strategy_id=strategy_id,
            limit=limit
        )
        
        return jsonify({
            'success': True,
            'data': results,
            'message': '获取回测结果成功'
        })
        
    except Exception as e:
        logger.error(f"获取回测结果失败: {e}")
        return jsonify({
            'success': False,
            'message': f'获取回测结果失败: {str(e)}'
        }), 500


@app.route('/api/backtest/results/<report_id>', methods=['GET'])
def get_backtest_detail(report_id):
    """获取回测结果详情"""
    try:
        # 这里可以实现获取具体回测结果的详细数据
        # 目前返回基本信息
        return jsonify({
            'success': True,
            'data': {
                'report_id': report_id,
                'message': '回测结果详情获取成功'
            },
            'message': '获取回测结果详情成功'
        })
        
    except Exception as e:
        logger.error(f"获取回测结果详情失败: {e}")
        return jsonify({
            'success': False,
            'message': f'获取回测结果详情失败: {str(e)}'
        }), 500


@app.route('/api/strategy-editor/templates', methods=['GET'])
def get_strategy_templates():
    """获取策略模板"""
    try:
        result = strategy_editor.get_strategy_templates()
        return jsonify(result)
    except Exception as e:
        logger.error(f"获取策略模板失败: {e}")
        return jsonify({
            'success': False,
            'message': f'获取策略模板失败: {str(e)}'
        }), 500


@app.route('/api/strategy-editor/validate', methods=['POST'])
def validate_strategy():
    """验证策略代码"""
    try:
        data = request.get_json()
        
        if 'code' not in data:
            return jsonify({
                'success': False,
                'message': '缺少必需参数: code'
            }), 400
        
        code = data['code']
        parameters = data.get('parameters', {})
        
        result = strategy_editor.validate_strategy(code, parameters)
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"验证策略失败: {e}")
        return jsonify({
            'success': False,
            'message': f'验证策略失败: {str(e)}'
        }), 500


@app.route('/api/strategy-editor/run', methods=['POST'])
def run_custom_strategy():
    """运行自定义策略"""
    try:
        data = request.get_json()
        
        # 验证必需参数
        required_fields = ['stock_code', 'start_date', 'end_date', 'code']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'缺少必需参数: {field}'
                }), 400
        
        # 提取参数
        stock_code = data['stock_code']
        start_date = data['start_date']
        end_date = data['end_date']
        code = data['code']
        parameters = data.get('parameters', {})
        initial_capital = data.get('initial_capital', 100000.0)
        commission_rate = data.get('commission_rate', 0.001)
        
        # 运行自定义策略
        result = strategy_editor.run_custom_strategy(
            stock_code=stock_code,
            start_date=start_date,
            end_date=end_date,
            code=code,
            parameters=parameters,
            initial_capital=initial_capital,
            commission_rate=commission_rate
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"运行自定义策略失败: {e}")
        return jsonify({
            'success': False,
            'message': f'运行自定义策略失败: {str(e)}'
        }), 500


@app.route('/api/strategy-editor/save', methods=['POST'])
def save_custom_strategy():
    """保存自定义策略"""
    try:
        data = request.get_json()
        
        # 验证必需参数
        required_fields = ['name', 'code']
        for field in required_fields:
            if field not in data:
                return jsonify({
                    'success': False,
                    'message': f'缺少必需参数: {field}'
                }), 400
        
        # 提取参数
        name = data['name']
        code = data['code']
        parameters = data.get('parameters', {})
        description = data.get('description', '')
        
        # 保存策略
        result = strategy_editor.save_custom_strategy(
            name=name,
            code=code,
            parameters=parameters,
            description=description
        )
        
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"保存自定义策略失败: {e}")
        return jsonify({
            'success': False,
            'message': f'保存自定义策略失败: {str(e)}'
        }), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """健康检查接口"""
    return jsonify({
        'success': True,
        'message': '策略API服务正常运行',
        'timestamp': datetime.now().isoformat()
    })


@app.errorhandler(404)
def not_found(error):
    """404错误处理"""
    return jsonify({
        'success': False,
        'message': '接口不存在'
    }), 404


@app.errorhandler(500)
def internal_error(error):
    """500错误处理"""
    return jsonify({
        'success': False,
        'message': '服务器内部错误'
    }), 500


def create_app(db_password: str = None):
    """创建Flask应用"""
    init_engines(db_password)
    return app


if __name__ == '__main__':
    # 启动API服务
    app = create_app()
    logger.info("启动策略API服务...")
    app.run(host='0.0.0.0', port=5000, debug=True)


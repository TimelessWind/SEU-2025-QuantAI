#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
策略编辑器模块
支持研究员编写自定义策略并进行回测
"""

import ast
import logging
import pandas as pd
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
import json
import uuid

from strategy_engine import BaseStrategy, StrategyEngine
from backtest_engine import BacktestEngine

# 配置日志
logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


class StrategyValidator:
    """策略代码验证器"""
    
    ALLOWED_IMPORTS = {
        'pandas', 'numpy', 'np', 'pd', 'math', 'datetime'
    }
    
    ALLOWED_FUNCTIONS = {
        'len', 'range', 'enumerate', 'zip', 'min', 'max', 'sum', 'abs',
        'round', 'int', 'float', 'str', 'bool', 'list', 'dict', 'tuple',
        'print', 'len', 'sorted', 'reversed'
    }
    
    FORBIDDEN_KEYWORDS = {
        'import', 'exec', 'eval', 'open', 'file', 'input', 'raw_input',
        '__import__', 'reload', 'compile', 'globals', 'locals', 'vars',
        'dir', 'hasattr', 'getattr', 'setattr', 'delattr'
    }
    
    @classmethod
    def validate_strategy_code(cls, code: str) -> Tuple[bool, str]:
        """
        验证策略代码的安全性
        
        Args:
            code: 策略代码字符串
            
        Returns:
            (是否有效, 错误信息)
        """
        try:
            # 解析AST
            tree = ast.parse(code)
            
            # 检查导入语句
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        if alias.name not in cls.ALLOWED_IMPORTS:
                            return False, f"不允许导入模块: {alias.name}"
                
                elif isinstance(node, ast.ImportFrom):
                    if node.module and node.module not in cls.ALLOWED_IMPORTS:
                        return False, f"不允许从模块导入: {node.module}"
                
                # 检查函数调用
                elif isinstance(node, ast.Call):
                    if isinstance(node.func, ast.Name):
                        if node.func.id in cls.FORBIDDEN_KEYWORDS:
                            return False, f"不允许调用函数: {node.func.id}"
                
                # 检查属性访问
                elif isinstance(node, ast.Attribute):
                    if isinstance(node.value, ast.Name) and node.value.id == 'pd':
                        # 允许pandas的基本操作
                        allowed_pd_methods = {
                            'rolling', 'mean', 'std', 'min', 'max', 'sum', 'count',
                            'shift', 'diff', 'ewm', 'expanding', 'fillna', 'dropna'
                        }
                        if node.attr not in allowed_pd_methods:
                            return False, f"不允许的pandas方法: {node.attr}"
            
            return True, "代码验证通过"
            
        except SyntaxError as e:
            return False, f"语法错误: {str(e)}"
        except Exception as e:
            return False, f"验证错误: {str(e)}"


class CustomStrategy(BaseStrategy):
    """自定义策略类"""
    
    def __init__(self, name: str, code: str, params: Dict[str, Any] = None):
        super().__init__(name, params or {})
        self.code = code
        self.compiled_code = None
        
    def compile_code(self) -> bool:
        """编译策略代码"""
        try:
            # 验证代码安全性
            is_valid, error_msg = StrategyValidator.validate_strategy_code(self.code)
            if not is_valid:
                raise ValueError(f"代码验证失败: {error_msg}")
            
            # 编译代码
            self.compiled_code = compile(self.code, '<strategy>', 'exec')
            return True
            
        except Exception as e:
            logger.error(f"策略代码编译失败: {e}")
            return False
    
    def generate_signals(self, data: pd.DataFrame) -> pd.DataFrame:
        """生成交易信号"""
        if not self.validate_data(data):
            raise ValueError("数据格式不正确")
        
        if not self.compiled_code:
            if not self.compile_code():
                raise ValueError("策略代码编译失败")
        
        try:
            # 准备执行环境
            df = data.copy()
            df = df.sort_values('trade_date').reset_index(drop=True)
            
            # 初始化信号和仓位
            df['signal'] = 0
            df['position'] = 0
            
            # 创建执行环境
            exec_globals = {
                'pd': pd,
                'np': np,
                'df': df,
                'len': len,
                'range': range,
                'enumerate': enumerate,
                'zip': zip,
                'min': min,
                'max': max,
                'sum': sum,
                'abs': abs,
                'round': round,
                'int': int,
                'float': float,
                'str': str,
                'bool': bool,
                'list': list,
                'dict': dict,
                'tuple': tuple,
                'print': print,
                'sorted': sorted,
                'reversed': reversed,
            }
            
            # 执行策略代码
            exec(self.compiled_code, exec_globals)
            
            # 获取修改后的DataFrame
            df = exec_globals['df']
            
            # 确保信号列存在
            if 'signal' not in df.columns:
                df['signal'] = 0
            if 'position' not in df.columns:
                df['position'] = 0
            
            return df
            
        except Exception as e:
            logger.error(f"策略执行失败: {e}")
            raise ValueError(f"策略执行失败: {str(e)}")


class StrategyTemplate:
    """策略模板管理器"""
    
    @staticmethod
    def get_templates() -> Dict[str, Dict[str, Any]]:
        """获取策略模板"""
        return {
            "moving_average_template": {
                "name": "双均线策略模板",
                "description": "基于移动平均线的策略模板",
                "code": """
# 双均线策略模板
# 参数: short_period, long_period, buy_threshold, sell_threshold

# 计算移动平均线
df['ma_short'] = df['close_price'].rolling(window=short_period).mean()
df['ma_long'] = df['close_price'].rolling(window=long_period).mean()

# 计算价格与均线的比率
df['price_ma_ratio'] = df['close_price'] / df['ma_short']

# 生成交易信号
for i in range(1, len(df)):
    # 买入信号：价格上穿短期均线且超过阈值
    if (df.loc[i, 'price_ma_ratio'] >= buy_threshold and 
        df.loc[i-1, 'price_ma_ratio'] < buy_threshold):
        df.loc[i, 'signal'] = 1  # 买入
        df.loc[i, 'position'] = 1
    
    # 卖出信号：价格下穿短期均线
    elif (df.loc[i, 'price_ma_ratio'] <= sell_threshold and 
          df.loc[i-1, 'price_ma_ratio'] > sell_threshold):
        df.loc[i, 'signal'] = -1  # 卖出
        df.loc[i, 'position'] = 0
    
    # 保持仓位
    else:
        df.loc[i, 'position'] = df.loc[i-1, 'position']
""",
                "parameters": {
                    "short_period": {"type": "int", "default": 5, "min": 1, "max": 100},
                    "long_period": {"type": "int", "default": 20, "min": 1, "max": 200},
                    "buy_threshold": {"type": "float", "default": 1.01, "min": 1.0, "max": 2.0},
                    "sell_threshold": {"type": "float", "default": 1.0, "min": 0.5, "max": 1.5}
                }
            },
            
            "rsi_template": {
                "name": "RSI策略模板",
                "description": "基于RSI指标的策略模板",
                "code": """
# RSI策略模板
# 参数: rsi_period, oversold_threshold, overbought_threshold

# 计算RSI
delta = df['close_price'].diff()
gain = (delta.where(delta > 0, 0)).rolling(window=rsi_period).mean()
loss = (-delta.where(delta < 0, 0)).rolling(window=rsi_period).mean()
rs = gain / loss
df['rsi'] = 100 - (100 / (1 + rs))

# 生成交易信号
for i in range(rsi_period, len(df)):
    # 超卖买入
    if df.loc[i, 'rsi'] < oversold_threshold:
        df.loc[i, 'signal'] = 1  # 买入
        df.loc[i, 'position'] = 1
    
    # 超买卖出
    elif df.loc[i, 'rsi'] > overbought_threshold:
        df.loc[i, 'signal'] = -1  # 卖出
        df.loc[i, 'position'] = 0
    
    # 保持仓位
    else:
        df.loc[i, 'position'] = df.loc[i-1, 'position']
""",
                "parameters": {
                    "rsi_period": {"type": "int", "default": 14, "min": 1, "max": 50},
                    "oversold_threshold": {"type": "float", "default": 30, "min": 0, "max": 50},
                    "overbought_threshold": {"type": "float", "default": 70, "min": 50, "max": 100}
                }
            },
            
            "breakout_template": {
                "name": "突破策略模板",
                "description": "基于价格突破的策略模板",
                "code": """
# 突破策略模板
# 参数: lookback_period, breakout_threshold

# 计算过去窗口的高低点（避免未来函数）
df['high_max'] = df['high_price'].rolling(window=lookback_period, min_periods=lookback_period).max().shift(1)
df['low_min'] = df['low_price'].rolling(window=lookback_period, min_periods=lookback_period).min().shift(1)

# 计算突破阈值
df['upper_threshold'] = df['high_max'] * (1 + breakout_threshold)
df['lower_threshold'] = df['low_min'] * (1 - breakout_threshold)

# 生成交易信号
start_idx = max(lookback_period, int(df['high_max'].first_valid_index() or 0) + 1)
for i in range(start_idx, len(df)):
    # 向上突破买入
    if df.loc[i, 'close_price'] > df.loc[i, 'upper_threshold']:
        df.loc[i, 'signal'] = 1  # 买入
        df.loc[i, 'position'] = 1
    
    # 向下突破卖出
    elif df.loc[i, 'close_price'] < df.loc[i, 'lower_threshold']:
        df.loc[i, 'signal'] = -1  # 卖出
        df.loc[i, 'position'] = 0
    
    # 保持仓位
    else:
        df.loc[i, 'position'] = df.loc[i-1, 'position']
""",
                "parameters": {
                    "lookback_period": {"type": "int", "default": 20, "min": 5, "max": 100},
                    "breakout_threshold": {"type": "float", "default": 0.02, "min": 0.001, "max": 0.1}
                }
            }
        }


class StrategyEditor:
    """策略编辑器"""
    
    def __init__(self, db_password: str = None):
        self.db_password = db_password
        self.strategy_engine = StrategyEngine(db_password)
        self.backtest_engine = BacktestEngine(db_password)
        self.logger = logger
    
    def validate_strategy(self, code: str, parameters: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        验证策略代码
        
        Args:
            code: 策略代码
            parameters: 策略参数
            
        Returns:
            验证结果
        """
        try:
            # 创建临时策略实例进行验证
            temp_strategy = CustomStrategy("temp", code, parameters or {})
            
            # 编译代码
            if not temp_strategy.compile_code():
                return {
                    "success": False,
                    "message": "策略代码编译失败",
                    "error_type": "compile_error"
                }
            
            return {
                "success": True,
                "message": "策略代码验证通过",
                "error_type": None
            }
            
        except Exception as e:
            return {
                "success": False,
                "message": str(e),
                "error_type": "validation_error"
            }
    
    def run_custom_strategy(self, stock_code: str, start_date: str, end_date: str,
                           code: str, parameters: Dict[str, Any] = None,
                           initial_capital: float = 100000.0,
                           commission_rate: float = 0.001) -> Dict[str, Any]:
        """
        运行自定义策略
        
        Args:
            stock_code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            code: 策略代码
            parameters: 策略参数
            initial_capital: 初始资金
            commission_rate: 手续费率
            
        Returns:
            回测结果
        """
        try:
            # 创建自定义策略
            strategy = CustomStrategy("custom_strategy", code, parameters or {})
            
            # 获取数据
            data = self.strategy_engine.get_stock_data(stock_code, start_date, end_date)
            if data.empty:
                raise ValueError(f"未获取到股票{stock_code}的数据")
            
            # 生成信号
            signals = strategy.generate_signals(data)
            
            # 模拟交易
            result = self.backtest_engine.simulate_trading(signals, initial_capital, commission_rate)
            
            return {
                "success": True,
                "data": result.to_dict(),
                "message": "自定义策略回测完成"
            }
            
        except Exception as e:
            self.logger.error(f"自定义策略运行失败: {e}")
            return {
                "success": False,
                "message": str(e),
                "data": None
            }
    
    def get_strategy_templates(self) -> Dict[str, Any]:
        """获取策略模板"""
        return {
            "success": True,
            "data": StrategyTemplate.get_templates(),
            "message": "获取策略模板成功"
        }
    
    def save_custom_strategy(self, name: str, code: str, parameters: Dict[str, Any] = None,
                           description: str = "") -> Dict[str, Any]:
        """
        保存自定义策略（到数据库或文件）
        
        Args:
            name: 策略名称
            code: 策略代码
            parameters: 策略参数
            description: 策略描述
            
        Returns:
            保存结果
        """
        try:
            # 验证策略
            validation_result = self.validate_strategy(code, parameters)
            if not validation_result["success"]:
                return validation_result
            
            # 生成策略ID
            strategy_id = f"CUSTOM_{uuid.uuid4().hex[:8]}"
            
            # 这里可以保存到数据库，暂时保存到文件
            strategy_data = {
                "strategy_id": strategy_id,
                "name": name,
                "code": code,
                "parameters": parameters or {},
                "description": description,
                "create_time": datetime.now().isoformat(),
                "type": "custom"
            }
            
            # 保存到文件（实际项目中应保存到数据库）
            import os
            strategies_dir = "custom_strategies"
            os.makedirs(strategies_dir, exist_ok=True)
            
            strategy_file = os.path.join(strategies_dir, f"{strategy_id}.json")
            with open(strategy_file, 'w', encoding='utf-8') as f:
                json.dump(strategy_data, f, ensure_ascii=False, indent=2)
            
            return {
                "success": True,
                "data": {"strategy_id": strategy_id},
                "message": "自定义策略保存成功"
            }
            
        except Exception as e:
            self.logger.error(f"保存自定义策略失败: {e}")
            return {
                "success": False,
                "message": str(e),
                "data": None
            }


if __name__ == "__main__":
    # 示例用法
    editor = StrategyEditor()
    
    # 获取策略模板
    templates = editor.get_strategy_templates()
    print("策略模板:", json.dumps(templates, ensure_ascii=False, indent=2))
    
    # 示例自定义策略代码
    custom_code = """
# 简单的价格突破策略
df['ma_20'] = df['close_price'].rolling(window=20).mean()
df['ma_5'] = df['close_price'].rolling(window=5).mean()

for i in range(20, len(df)):
    if df.loc[i, 'ma_5'] > df.loc[i, 'ma_20'] and df.loc[i-1, 'ma_5'] <= df.loc[i-1, 'ma_20']:
        df.loc[i, 'signal'] = 1
        df.loc[i, 'position'] = 1
    elif df.loc[i, 'ma_5'] < df.loc[i, 'ma_20'] and df.loc[i-1, 'ma_5'] >= df.loc[i-1, 'ma_20']:
        df.loc[i, 'signal'] = -1
        df.loc[i, 'position'] = 0
    else:
        df.loc[i, 'position'] = df.loc[i-1, 'position']
"""
    
    # 验证策略
    validation = editor.validate_strategy(custom_code)
    print("验证结果:", validation)
